import SwaggerUI from 'swagger-ui'
import 'swagger-ui/dist/swagger-ui.css';

async function start(){
	var response = await fetch("https://raw.githubusercontent.com/InfoELSBIotEcoSystem/openBOS-API-Doc/main/assets/openbos-documentation/static/images/openBOS-swagger.json");
	const spec = await response.json();
	const ui = SwaggerUI({ spec, dom_id: '#swagger' });

	ui.initOAuth({
	  clientId: "your-client-id",
	  appName: "openBOS API",
	  scopeSeparator: " ",
	  scopes: "api://openbos/Relation.Read api://openbos/License.Read api://openbos/BosApi.Proxy api://openbos/User.Delete api://openbos/Relation.ReadWrite api://openbos/License.ReadWrite offline_access",
	  usePkceWithAuthorizationCodeGrant: true
	});
};

start();